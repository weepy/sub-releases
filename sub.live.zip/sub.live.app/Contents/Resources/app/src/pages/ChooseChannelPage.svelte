<script>
import HeadphonesRecommended from '../components/HeadphonesRecommended.svelte'
import { nativeBridge } from '../stores/NativeStore.js'
// import JoinChannelForm from '../components/JoinChannelForm.svelte'
// import CreateChannelForm from '../components/CreateChannelForm.svelte'
import { joinChannel } from '../stores/WebStore.js'
import { TextField, Button } from 'svelte-materialify'
import { onMount } from 'svelte'


onMount(() => {
    nativeBridge.send("STOP_CAPTURE")
    track("ChooseChannelPage")
}) 


const recent = LocalStore("visitedChannels") || []

let channelId =''
let channelName = ''

$: channelName = channelName.toLowerCase()//.replace(/[^a-z0-9_]/g, '')

let err = false

function join() {      
    
    err = channelIdRules.find(rule => typeof rule(channelId) == "string")
    if(err) {
        // alert("bad channel id")
    }
    else {
        getDevicesAndJoinChannel(channelId)
    }
}   

function create() {
    err = channelNameRules.find(rule => typeof rule(channelName) == "string")

    if(err) {
        // alert("bad channel name")
    }
    else {
        const cid = channelName + "#" + Math.random().toString(36).slice(2)
        getDevicesAndJoinChannel(cid)
    }
    
}


function getDevicesAndJoinChannel(cid) {

    // refreshDevices(() => {
        joinChannel(cid)
    // })
}


const channelNameRules = [
    (v) => !!v || "Required",
    (v) => (/^[a-z0-9_]+$/).test(v) || "Channel name can only contain letters, numbers and _",
    (v) => v.length > 0 || "Minimum length is 1"
]

const channelIdRules = [
    (v) => !!v || "Required",
    (v) => ((/^[a-z0-9_]+#[a-z0-9]+$/).test(v)) || "invite code is wrong!",
    (v) => v.length > 4 || "Minimum length is 5"
]
</script>

{#if recent.length}
    <div class="ma-5 recent-channels">
        <h6>Recently visited rooms</h6>
            {#each recent as channel_id}
                <!-- svelte-ignore a11y-missing-attribute -->
                <Button 
                    style="margin-right:20px; margin-bottom:10px;text-transform:none" 
                    class="primary-color"  
                    on:click={() => getDevicesAndJoinChannel(channel_id)}>#{channel_id.split("#")[0]}
                </Button>
            {/each}
        </div>
    <br/>
{/if}

<div class="ma-5 mb-10">
    <h6  class="mb-2">Join a room with an invite code</h6>
    <div style="position:relative; height: 70px">
    <TextField
        
        rules={channelIdRules}
        bind:value={channelId} 
        style="width:200px;display:inline-block"
        placeholder="invite code" autocomplete="off" spellcheck="false" 
        validateOnBlur={true}
        >
        
    </TextField> <Button class="primary-color"  on:click={join}>Join</Button>
    </div>
    

</div>


<div class="ma-5">
    <h6  class="mb-2">Create a new room</h6>
    <div style="position:relative; height: 70px">
    <TextField
        
        rules={channelNameRules}
        bind:value={channelName} 
        style="width:200px; display:inline-block"
        placeholder="room name" autocomplete="off" spellcheck="false" 
        validateOnBlur={true}
        >
        
    </TextField> <Button  class="primary-color"  on:click={create}>Create</Button>
    </div>
    

</div>

<HeadphonesRecommended />


<style>
    :global(.recent-channels .s-btn__content) {
        text-transform: none;
    }
</style>