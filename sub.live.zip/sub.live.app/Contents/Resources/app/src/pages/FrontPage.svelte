<script>
import { nativeBridge } from '../stores/NativeStore.js'
import {TextField,Button} from 'svelte-materialify'
import HeadphonesRecommended from '../components/HeadphonesRecommended.svelte'

import { onMount } from 'svelte'
import { myStreamId, currentUser } from '../stores/Shared.js'
import config from '../config.js'
// import { tcpState, login } from '../stores/WebStore.js'
// import { udpAddress } from '../stores/NativeStore.js'


onMount(() => {
    nativeBridge.send("STOP_CAPTURE")
    track("FrontPage")
}) 

const usernameRules = [
    v => !!v || 'Required',
    v => v.length >= 3 || "Minimum length is 3",
    v => v.length <= 16 || "Maximum length is 16",
    v => v.match(/^[a-z0-9_]+$/) || "letters, numbers and _"
]

let username

function randomInt31() {
	return Math.floor(Math.random()*(Math.pow(2,31)-1))
}

function doLogin() {

    for(let i=0; i<usernameRules.length;i++) {
        const rule = usernameRules[i]
        if( typeof rule(username) == "string")
            return
        
    }

    const sid = randomInt31()
    myStreamId.set(sid)
    currentUser.set({ username, sid })
    if(config.TRACKING) {
        mixpanel.identify(username+"-"+sid.toString(36))
    }
    
}

import { Logo } from "../components/ImagesBase64.js"



</script>


<!-- svelte-ignore a11y-missing-attribute -->
<img style="width:200px" src={Logo} />
<main>
<p style="margin-bottom:30px"><span><b>sub</b></span> is a <mark>live audio</mark> network for <mark2>musicians</mark2> to <x>play</x> together
    </p>

<h6>Enter your username: </h6>
<TextField bind:value={username} 
    
    rules={usernameRules}
    autocomplete="nope" 
    spellcheck="false" 
    autocorrect="new-password" 
    autocapitalize="off"
    style="width:240px"
    outlined>
    username</TextField>

<Button class="primary-color" on:click={doLogin} >Login</Button>


<br/><br/><br/>


</main>

<HeadphonesRecommended />
<style>

mark {
    background: #ffa2ffc4;
    font-style:italic;
    padding-right: 4px;
}

mark2 {
    background: #ffe25ff5;
    font-style:italic;
    color: black;
    padding-right: 4px;

}
x {
    border-bottom: 1px dotted white;
}
main {
    font-size: 30px;
    margin-left: 30px;
}

</style>