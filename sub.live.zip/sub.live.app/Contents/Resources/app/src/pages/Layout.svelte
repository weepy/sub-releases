<script>
import { MaterialApp,Footer,Avatar, AppBar, Icon, Subheader, Dialog, Button} from 'svelte-materialify'

import { currentUser } from '../stores/Shared.js'
import SvgFilters from "../components/SvgFilters.svelte"
import SvgFiltersInsta from "../components/SvgFiltersInsta.svelte"

import Connection from '../components/Connection.svelte'
import { logout } from '../stores/WebStore.js'
// import config from '../config.js'
import DebugPanel from '../components/DebugPanel.svelte'

import tooltip from '../components/ui/tooltip.js'


let showDebug = false


function handleKeydown(event) {
    
    if(event.key == "d" && event.metaKey) {
        showDebug = true
    }
}

let showFeedback 
function clickFeedback() {
    showFeedback=true
}

function panic() {

    track("panic")
    setTimeout(()=> {
        document.location.reload()
    }, 100)
}

</script>
<MaterialApp theme="dark" >
    <AppBar style="-webkit-app-region: drag">
        <div slot="icon">
            
    
        </div>
        <span slot="title" style="font-size:24px;padding-left:220px">
            
            <img src="assets/sub-logo-white.png" style="height:24px;transform:translate(0px, 4px)" alt="Logo" />
            <b>sub</b>.live
        </span>

        <span style="right:20px;position: absolute; display:inline-block">

    
            <Button on:click={clickFeedback}>
                <!-- <p>Any issues please contact jonahfox@gmail.com or Whatsapp +4520577996</p> -->
                ↗ Feedback
            </Button>
        </span>
      </AppBar>
      <div style="padding:40px; padding-top:20px;">
        <slot>
            HTML CONTENT GOES HERE!
        </slot>
    </div>



    <div style="height: 200px;bottom:0;">
        <Footer class="pa-2" absolute>
            <Connection />
            {#if $currentUser }
            
                <span class="username">{$currentUser.username} </span>
                <button class="logout" on:click={logout} >logout</button>
            
            <!-- {:else}
                <span>Not logged in</span> -->
            {/if}   
            <button class="panic" use:tooltip={{text:"Reload page",style:"margin-left:-70px"}}  on:click={panic}>
                panic!
            </button>
        </Footer>
    </div>


    <DebugPanel bind:showDebug={showDebug} />

    <Dialog bind:active={showFeedback}>
            
        <div class="pa-5">
            <h5>↗ Feedback</h5>

            <br/>
                
            <p>
                Send any ideas or issues to:
            </p>
            <p>
                <a class="button" style="font-weight:bold; color:hotpink" target="_email" href="mailto:jonahfox@gmail.com">jonahfox@gmail.com</a>
            </p>
        
            <!-- <p>
                💬 : <a class="button" target="_discord" href="https://discord.gg/H8HZBtXDYH">
                    discord chat
                 </a> ↗
            </p> -->

            <br/>
            <!-- <h7>Don't be shy - come say hi!</h7> -->
            
        

        </div>
    </Dialog>


</MaterialApp>

<svg width="0" height="0">
    <defs>
        <clipPath id="squircle2" clipPathUnits="objectBoundingBox">
        <path d="M .5,0 C .1,0 0,.1 0,.5 0,.9 .1,1 .5,1 .9,1 1,.9 1,.5 1,.1 .9,0 .5,0 Z"/>
        </clipPath>
    </defs>
</svg>

<SvgFilters />
<!-- <SvgFiltersInsta /> -->

<svelte:window on:keydown={handleKeydown} />

<style>

button {
    font-size:12px;
    outline:none;

}

.username {
    font-weight: bold;
    margin-right: 10px;
    margin-left: 70px;
}

.panic {
    margin-left: auto;
    margin-right:20px;
    color: pink;
    border: 1px solid #ffc0cb73;
    /* transform: translate(90px, 0px); */
    border-radius: 10px;
    padding: 0px 9px;

}

.logout {
    font-size: 10px;
    color: #aaa;
}
</style>