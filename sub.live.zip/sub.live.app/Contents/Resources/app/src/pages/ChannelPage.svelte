<script>
import { onMount} from "svelte"

import tooltip from '../components/ui/tooltip.js'
import MyToolbar from '../components/MyToolbar.svelte'
import MySettings from '../components/MySettings.svelte'



import {  volumes, stats, tofs, copyNative, nativeBridge} from "../stores/NativeStore.js"
import {  leaveChannel } from "../stores/WebStore.js"
import {  currentCid, channelUsers, myStreamId } from '../stores/Shared.js'



import { audioInit, audioTerminate, getDevices } from '../stores/DeviceStore.js'

import UserPanel from '../components/UserPanel.svelte'


import { mdiAccountPlus, mdiCog, mdiVolumeHigh, mdiVolumeMute, mdiHelp, mdiExitToApp} from '@mdi/js'



import { Dialog, Icon, Button } from "svelte-materialify"



$: if($currentCid) {
    
    let visited = (LocalStore("visitedChannels")||[])

    visited = visited.filter( cid => cid != $currentCid)
    visited.unshift($currentCid)

    LocalStore.set("visitedChannels", visited)
}

// let myStream


onMount(() => {
    let startTime = Date.now()
    track("ChannelPage", {"channel": $currentCid })

    getDevices()

    setTimeout(() => {
        audioInit()
    }, 200)


    return (() => {

        audioTerminate()

        let seconds = (Date.now()-startTime)/1000
        
        track("SessionDuration", { channel: $currentCid, seconds })
    })
})

let showInvitePanel = false
let copied = false
function showInvite() {
    // copyNative($currentCid)
    copied = false
    showInvitePanel = true    
}

function copyToClipBoard() {
    copyNative($currentCid)
    copied = true
}

let showSettings = false
let showHelp = false

let otherUsers = []

$: otherUsers = $channelUsers.filter(u => u.sid != $myStreamId)




function doLeaveChannel() {
    nativeBridge.send("STOP_CAPTURE")
    leaveChannel() // web
}




</script>

{#if $currentCid}
    <h4 class="mb-5 d-flex">
        <span class="channelId">#{$currentCid.split("#")[0]}</span>
            
        
        <div style="margin-right:20px; margin-left: auto" use:tooltip={{text: "Invite",style:"margin-left:-60px"}}>
        <Button  on:click={showInvite}>
            <Icon path={mdiAccountPlus} /> 
    
        </Button>
        </div>

        <div use:tooltip={{text: "Leave Room", style:"margin-left:-80px"}}>
            <Button on:click={doLeaveChannel} ><Icon path={mdiExitToApp}/></Button>
        </div>

    </h4>

    
    <div class="mb-5">
        
        <div class="users">
            {#each otherUsers as user, index (user.sid)}
            
                
                    <UserPanel 
                        {user} 
                        {index}
                        
                        stats={$stats[user.sid]}
                        volume={$volumes[user.sid]} 
                        tof={$tofs[user.sid]}
                    />

            
            {/each}

            {#if otherUsers.length == 0} 
                <!-- svelte-ignore a11y-distracting-elements -->
                <p>
                    Waiting for other users ...    
                </p>
                
            {/if}
        </div>
        
        
    </div>

    <div class="mytoolbar d-flex" style="width:520px">
    <MyToolbar bind:showHelp={showHelp} bind:showSettings={showSettings} />
    </div>

    <MySettings bind:active={showSettings}/>
    
    

    <Dialog bind:active={showInvitePanel} > 
        <div class="pa-5 tips">

        <h5>Invite user</h5>
        <p> Give this code to friends to so they can join this room</p>
        <code on:click={copyToClipBoard}> { $currentCid }</code> <button on:click={copyToClipBoard} class="copy-button primary-color">{copied?"Copied!":"Copy"}</button>
        </div>
    </Dialog>
    <Dialog bind:active={showHelp}>
            
        <div class="pa-5 tips">
            <h5>Tips to improve latency</h5>
            <br/>
            <ul> 
                <li>People closer will have lower latency</li>
                <li>Use ethernet rather than Wifi</li>
                <li>Use wired headphones</li>
                <li>Some ISP packages have better connections</li>
                <li>Lower buffer => lower latency, but too low and you will get dropouts</li>
                <li>Close other network hungry apps [e.g browers]</li>
            </ul>
            <br/>
            <Button class="primary-color" on:click={() => showHelp = false}>OK</Button>
        </div>
    </Dialog>


{:else}
    <p>Leaving..</p>
{/if}




<style>
.tips li {
    font-size: 13px;
    line-height: 30px;
    font-family: Helvetica;
}
.users {
    display: flex;
    flex-wrap: wrap;
}

.waiting {
    /* animation: fadeIn 10s; */
}

@keyframes fadeIn {
    0% {opacity:0;}
    100% {opacity:1;}
}

.mytoolbar {
    align-items: center;
    /* justify-content: center; */
    position: absolute;
    bottom: 0px;
    
    height: 170px;
    width: 100%;
}



.channelId {
    user-select: text;
    --webkit-user-select: text;
    cursor: text;
}

.copy-button {
    padding: 4px 15px;
    font-size: 12px;
    border-radius: 13px;
}

code {
    padding: 5px;
}
</style>