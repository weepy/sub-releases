import { get, writable } from 'svelte/store'
import { writableLocalStorage} from '../lib/utils.js'

import config from '../config.js'
const ns = config.NAMESPACE+"_"

export const myVideoStream = writable(null)

export const myStreamId = writableLocalStorage(ns+"myStreamId",null)


export const joinedRoom = writable()

export const currentCid = writableLocalStorage(ns+"currentCid", null) // i.e. not saved between sessions
export const currentUser = writableLocalStorage(ns+"currentUser", null)
export const channelUsers = writable([])


if(config.NATIVE) {
    currentCid.set(null) // 
}

export const masterGain = writableLocalStorage(ns+"masterGain", 1)
export const bitRate = writableLocalStorage(ns+"bitRate", 96)

