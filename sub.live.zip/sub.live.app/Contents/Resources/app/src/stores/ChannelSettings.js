import { currentCid } from "./Shared.js"
import { nativeBridge } from '../stores/NativeStore.js'

import config from '../config.js'

let currentKey
 
export let channelSettings = null

currentCid.subscribe(cid => {

    if(!cid) {
        channelSettings = null
        currentKey = null
    }
    else {

        currentKey = config.NAMESPACE + "_" + "channelSettings:"+cid
        try {
            channelSettings = JSON.parse(localStorage[currentKey])
        }
        catch(e) {
            channelSettings = {}
        }

        
    }
})


export function getDefaultPan(user) { // random!

    let i = Math.random() * 0.4+0.3 // 0.3-0.7

    i *= (Math.random() > 0.5 ? 1: -1) // [-0.7,-0.3],[0.3,0.7]
    i = i * 0.5 + 0.5
    
    return Math.floor(i*100) / 100 
}


export function updateChannelSettings(sid, o) {

    let cur = channelSettings[sid] = channelSettings[sid] || {}

    for(let i in o) {
        cur[i] = o[i]
    }
    
    localStorage[currentKey] = JSON.stringify(channelSettings)

    nativeBridge.send("SET_STREAM", Object.assign({sid}, o))
}