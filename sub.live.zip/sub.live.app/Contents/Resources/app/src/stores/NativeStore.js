import ElectronBridge from '../lib/ElectronBridge.js'

import { writable, get } from 'svelte/store'    

import config from '../config.js'

import { 
    masterGain,
    
    myStreamId,
    bitRate,
    channelUsers
} from './Shared.js'


export const udpAddress = writable(null)

export const volumes = writable({})
export const stats = writable({})
export const tofs = writable({})


export const handlers = {
    // url: "ws://localhost:6969",
    CONNECTED(config) {
        
        console.log("config:", config)
        window.config = config
    },

    SHELL_OPEN() {
        nativeBridge.send("SET_INFO_FREQUENCY", 40) // rare!
    },
    
    INFO(...args) {
        console.log.apply(console, args)
    },

    ERROR(...args) {
        console.error.apply(console, args)
    },
    STATS(s) {
        stats.set(s)
    },

    TOF(userid, delta) {
        tofs.update($tofs => (Object.assign({}, $tofs, { [userid]: delta })))
    },
    
    LOCATED(arg) {
        nativeBridge.send("SET_BOUNCE_AUDIO", config.BOUNCE_AUDIO=="YES")
        udpAddress.set(arg)
        
    },

    DIED() {
        alert("Sorry unexpected system error. Click OK to reload", () => {
            document.location.reload()
        })
    },
    
    VOLUMES(v) {
        // console.log(x) 
        // const v = {}
        // for(let i=0; i<arr.length; i+=2 ) {
        //     const userid = arr[i]
        //     v[userid] = arr[i+1]
        // }

        volumes.set(v)
    }
}

// let refreshDevicesCallback

export const nativeBridge = new ElectronBridge(handlers)

// setTimeout(() => {
// 	nativeBridge.send("HIDE_SPLASH")
// },200)

masterGain.subscribe(x => {
    nativeBridge.send("SET_MASTER_GAIN", x)
})


bitRate.subscribe(x => {
    nativeBridge.send("SET_BIT_RATE", x/2)
})

const isChrome = true //navigator.userAgent.includes("Chrome") && navigator.vendor.includes("Google Inc")

export function copyNative(str) {
    nativeBridge.send("COPY", str)
    
    
    if(isChrome) {

        var textArea = document.createElement("textarea");
        textArea.value = str;
        textArea.style.position="fixed";  //avoid scrolling to bottom
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
    
        try {
            var successful = document.execCommand('copy');
            var msg = successful ? 'successful' : 'unsuccessful';
            console.log(msg); 
        } catch (err) {
            console.log('Was not possible to copy te text: ', err);
        }
    
    }
}



// export function setStream(sid, o) {
//     nativeBridge.send("SET_STREAM", {sid, ...o})
// }

myStreamId.subscribe((sid) => {
    nativeBridge.send("SET_MY_STREAMID", sid)
})


// export function refreshDevices(fn){
//     refreshDevicesCallback = fn
//     nativeBridge.send("REFRESH_DEVICES")
// }

// setInterval(refreshDevices, 1000)

export function stopCapture() {
    nativeBridge.send("CAPTURE_STOP") 
}


export function udpLocate() {
    const addr = get(udpAddress)
    // console.log("updateLocate")
	if( addr == null ) {
        console.log("updateLocate try again")

        let [protocol, hostport] = config.SERVER.split("://")
        let [host, port] = hostport.split(":")
        
        port=parseInt(port)+1

		nativeBridge.send("LOCATE", {host, port, protocol})
		setTimeout(udpLocate, 500)
	}
}

channelUsers.subscribe(users  => {

    const users_ = users.map(u => {
        const {peer, ...rest} = u
        return rest
    })
    nativeBridge.send("SET_USERS", users_)
})