import { get, writable } from 'svelte/store'

import { writableLocalStorage} from '../lib/utils.js'
import { handlers, nativeBridge } from "./NativeStore.js"

export const devices = writable([])

import config from '../config.js'
const ns = config.NAMESPACE+"_"


function defaultInput() {
    return get(devices).find(d => d.defaultInput)
}

function defaultOutput() {
    return get(devices).find(d => d.defaultOutput)
}



export const inputName = writableLocalStorage(ns+"inputName", null)
export const outputName = writableLocalStorage(ns+"outputName", null)


export function getDevices() {
    nativeBridge.send("GET_DEVICES")
}

export function audioInit() {
    

    const $inputName = get(inputName)
    const $outputName = get(outputName)
    //if($inputName && $outputName) {
        nativeBridge.send("START_CAPTURE_WITH_DEVICES", {inputName:$inputName, outputName: $outputName})
    // }
    
}


export function audioTerminate() {
    nativeBridge.send("STOP_CAPTURE")
}

// function removeCompany(name){
//     const bits = name.split(":")
//     bits.shift()
//     return bits.join(":") 
// }

handlers.CAPTURE_INPUT_FAILED = (deviceName) => {
    
    // const din = defaultInput()

    // alert("Could not capture input device: `" + removeCompany(deviceName) + "`. Resetting to `" + removeCompany(din.name) + "`")
    
    // inputName.set(din.name)
    
    // changeDevices()
}

handlers.CAPTURE_OUTPUT_FAILED = (device) => {
    
    // const dout = defaultOutput()

    // alert("Could not capture output device: `" + removeCompany(deviceName) + "`. Resetting to `" + removeCompany(dout.name) + "`")
    
    // outputName.set(dout.name)
    // changeDevices()
}


handlers.DEVICES = ($devices) => {
    devices.set($devices)
    
    const din = defaultInput()
    

    if(!get(inputName) && din) {
        
        inputName.set(din.name)
    }

    const dout = defaultOutput()

    if(!get(outputName) && dout) {
        outputName.set(dout.name)
    }

}

    
export function changeDevices() {
    const $inputName = get(inputName)
    const $outputName = get(outputName)
    nativeBridge.send("START_CAPTURE_WITH_DEVICES", {inputName:$inputName, outputName: $outputName})
}