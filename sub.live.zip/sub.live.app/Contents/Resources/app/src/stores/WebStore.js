import {myStreamId, currentUser, channelUsers, currentCid, joinedRoom } from './Shared.js'

import { writable, get } from 'svelte/store'

export const tcpState = writable("disconnected")

import Sock from '../lib/Sock.js'
import { udpAddress, udpLocate } from './NativeStore.js'
import config from '../config.js'


let url = config.SERVER


export const sock = new Sock(url, {
	CONNECT() {
		tcpState.set("connected")
		udpLocate()
	},
	
	DISCONNECT() {
		tcpState.set('disconnected')	
		udpAddress.set(null)
	},

	JOIN_FAILED(err) {
		window.alert(err)
	},

	JOINED_CHANNEL(cid, users) {
		currentCid.set(cid)
		joinedRoom.set(true)
		let my_sid = get(myStreamId)

		users.forEach(user => {
			if(user.sid == my_sid)
				return
			
			const initiator = user.sid > my_sid
			user.peer = new window.SimplePeer({initiator, trickle: true, channelConfig: {
				ordered:false, maxRetransmits: 0
			}})
			
			user.peer.sid = user.sid
		})

		channelUsers.set(users)
	},
	
	LEFT_CHANNEL() {
		const users = get(channelUsers)
		joinedRoom.set(false)

		users.forEach(u => {
			if(u.peer) {
				u.peer.destroy()
				delete u.peer
			}
		})
		
		channelUsers.set([])
		currentCid.set(null)
	},


	USER_JOINED(user) {
		const users = get(channelUsers)

		users.push(user)
		let my_sid = get(myStreamId)
		const initiator = user.sid > my_sid
		user.peer = new window.SimplePeer({initiator, trickle: true, channelConfig: {
			ordered:false, maxRetransmits: 0
		}})
		user.peer.sid = user.sid

		channelUsers.set(users)
		
	},

	USER_LEFT(sid) {
		const users = get(channelUsers)

		users.forEach(u => {
			if(u.sid == sid) {
				u.peer.destroy()
				delete u.peer
			}
		})
		
		const remainingUsers = users.filter(u => u.sid != sid)
		channelUsers.set(remainingUsers)
	},




	CHAT(channel) {
	// 		currentChannel.set(channel)
	},

	SIGNAL({to, signal, from }) {
		let my_sid = get(myStreamId)

        if(to != my_sid) {
            throw new Error("to != my_id")
        }

		const users = get(channelUsers)
		
        const user = users.find( u => u.sid == from)
		
		if(user) {
			user.peer.signal(signal)
		}
		else {
			console.error("could not find user with id", from)
		}
	}

	
})

sock.connect()



udpAddress.subscribe((addr) => {
	
	if(addr) {
		const user = get(currentUser)
		
		const cid = get(currentCid)

		if(user && cid) {
			
			joinChannel(cid)
		}
		
	}
})

export function joinChannel(cid) {
    let sid = get(myStreamId)
	sock.run("JOIN", {cid, username: get(currentUser).username, sid, udp: get(udpAddress) })
}

export function emitSignal(to, signal) {
    sock.run("SIGNAL", { to, signal })
}


export function leaveChannel() {
	// myStreamId.set(null)
	currentCid.set(null)
	channelUsers.set([])
	sock.run("LEAVE")
}

export function chat(text) { 
	
	sock.run("CHAT", {text})
}





// export function login(user) { 
// 	sock.run("LOGIN", user)
// }

export function logout() { 
	track("logout")
	currentUser.set(null)
	currentCid.set(null)
	channelUsers.set([])
	localStorage.clear()
	sock.close()
}

