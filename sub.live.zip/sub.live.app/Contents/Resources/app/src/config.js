const config = {
    NAMESPACE:"",
    COLOR:"black",
    SERVER:"wss://b33p.live:1234",
    VERSION:"0.2.0",
    BOUNCE_AUDIO:"NO",
    OS:"chrome.11.2.0",
    TRACKING: false
}

const configHash = localStorage.configHash || (document.location.hash.slice(1))

configHash.split(",").forEach( b => {
    const [key, value] = b.split("=")
    if(key)
        config[key] = value
})




console.log("configuration : ", config)

function LocalStore(_key) {
    const key = LocalStore.NAMESPACE + _key
    let val = null
	try {
		val = JSON.parse(localStorage[key])
	}
	catch(e) {
		val = null
	}

    return val
}

LocalStore.set = function(_key, val) {
    const key = LocalStore.NAMESPACE + _key
    localStorage[key] = JSON.stringify(val)
}

window.LocalStore = LocalStore
LocalStore.NAMESPACE = config.NAMESPACE


export function writableLocalStorage(key, _default) {
	
	const prop = writable(val)

	prop.subscribe(v => localStorage[key] = JSON.stringify(v))
	return prop
}


export default config