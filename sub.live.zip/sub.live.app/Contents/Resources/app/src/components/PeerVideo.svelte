<script>
import { onDestroy } from 'svelte'
import { fade } from 'svelte/transition'




import { myVideoStream} from '../stores/Shared.js'
export let peer


export let emitSignal
export let nick = "@"

let video

let addedStream

$: {
    if($myVideoStream) {
        if(!addedStream) {
            peer.addStream($myVideoStream)
            addedStream = $myVideoStream
        }
    }
    else {
        if(addedStream) {
            peer.removeStream(addedStream)
            addedStream = null
        }
    }
}

onDestroy(() => {
    peer.destroy()
})



peer.on('signal', signal => {
    
    emitSignal(peer.sid, signal)
})


peer.on('stream', stream => {
    console.log("peer stream")

    video.muted = true
    video.autoplay = true
    video.playsinline = true
    video.srcObject = stream
    

    stream.getTracks().forEach(track => {
        track.addEventListener('mute', () => {
            video.srcObject = null 
        })
    })

})

peer.on('connect', () => {
    console.log("peer connect")
})

peer.on('data', (data) => {
    console.log("peer data")
})

peer.on('close', () => {
    console.log("peer close")
})

peer.on('error', err => {
    console.log('peer error', err)
})


let filterName = localStorage.defaultSvgFilter || "" // "pink-acid"
$: videoStyle = filterName ? `filter:url(#${filterName})` : ''

</script>


<div class=outer>
    <h5>{nick}</h5>
    
    <!-- svelte-ignore a11y-media-has-caption -->
    <video bind:this={video} style={videoStyle} />
    
 

    <!-- <svg viewBox="0 0 1 1"  >
    
        <path
            stroke="currentColor"
			fill="transparent"
							
            d="M 0.01,0.5 C 0.01,0.01 0.01,0.01 0.5,0.01 S 0.99,0 0.99,0.5 .99,.99 0.5,.99 0.01,.99 0.01,0.5"
        />
        
    </svg> -->

    <!-- <svg viewBox="0 0 204 204">
        <rect x="1" y="1" width="203" height="203" rx="30" stroke-width="1" fill="transparent" stroke="currentColor" />
    </svg> -->
</div>

<style>
.outer {
    width:198px;
    height:198px;
    border:1px solid black;
    overflow:hidden;
    position:relative;
    border-radius: 39px;
}
video {
    width: 198px;
    height: 198px;
    /* border-radius: 50px; */
    /* clip-path: url(#squircle); */
    position: absolute;
    top: 0px;
    left: 0px;
    /* background: red; */
    
    
    
    /* background: black; */
}

h5 {
    width:198px;
    text-align:center;
    margin-top: 80px;
    /* z-index:1; */
    position:absolute;

}

</style>