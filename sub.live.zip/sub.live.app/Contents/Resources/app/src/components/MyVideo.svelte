<script>
import { mdiVideo, mdiVideoOff, mdiPlay } from '@mdi/js'
import { Icon } from "svelte-materialify"
import Spinner from './ui/Spinner.svelte'

import { myVideoStream } from '../stores/Shared.js'

// export let emitStream

let myVideo

let streamStarting

export let volume = -100

import config from '../config.js'

const [platform, major, minor, patch] = config.OS.split(".")
let disabledVideo = major < 10 || (major == 10 && minor < 14)




$: {
    if(myVideo) {
        myVideo.pause()
        myVideo.srcObject = $myVideoStream
        
        if($myVideoStream) {
            myVideo.muted = true
            myVideo.play()
        }
    }
}

import { volumeToColor } from '../lib/utils.js'



$: borderStyle = "border-color: " + volumeToColor(volume) 

function startCapture() {


    streamStarting = true

    navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { width: 120, height: 120, frameRate:10 }
    })
    .then(s => {
        myVideoStream.set(s)
        streamStarting = false
        



    })
    .catch((err) => {
        console.log("ERROR", err) 
        streamStarting = false
    })

}

function stopCapture() {
    const tracks = $myVideoStream.getTracks()

    tracks.forEach(function(track) {
        track.stop();
    })
    myVideoStream.set(null)

    
}

export let playing = false

$: {
    if(playing) {
        startCapture()
    }
}
$: {
    if(!playing) {
        if($myVideoStream) {
            stopCapture()
        }
    }
}

let showStopIcon = false

function handleMouseOver() {
    if(playing) {
        showStopIcon = true
    }
}

function handleMouseOut() {
    showStopIcon = false
}

function toggleCapture() {

    if(disabledVideo) {

        alert("Sorry, video capture needs Macos Mojave 10.14 or later 😢. You are running " + config.OS)
        return
    }
    playing = !playing
    
    track(playing ? "camOn" : "camOff")
}

</script>

<div class="wrapper" style="{borderStyle}" class:disabledVideo class:noStream={!$myVideoStream} on:click={toggleCapture} on:mouseenter={handleMouseOver} on:mouseout={handleMouseOut}>
    <!-- svelte-ignore a11y-media-has-caption -->
    <video bind:this={myVideo} />

        <div >
            {#if !playing }
                <Icon path={mdiVideo} />
            {:else if !$myVideoStream }
                <Spinner style="width:20px;color:white;margin-top:-14px;margin-left:2px;" />
            {:else if showStopIcon}
                <Icon path={mdiVideoOff}  />
            {/if}

        </div>
</div>




<style>

.disabledVideo {
    opacity: 0.2
}
.wrapper {
    position: relative;
    width:54px;
    height:54px;
    border-radius:14px;
    background:black;
    overflow:hidden;
    margin-right:10px;
    margin-top:-20px;
    cursor:pointer;
    border:1px solid rgb(0, 114, 0);
    transition: border-color 0.5s;
}

.wrapper div {
    position:absolute;
    top:14px;
    left:15px;
    width:100%;
    
    height:100%;
    pointer-events: none;
}

video {
    position:absolute;
    top:1px;
    left:1px;
    width:50px;
    height:50px;
    border-radius: 13px;
    pointer-events: none;
}

</style>