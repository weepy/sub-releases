<script>
    import { onMount} from "svelte"
    
    import tooltip from '../components/ui/tooltip.js'
    import MyVideo from '../components/MyVideo.svelte'
    
    
    import {  volumes } from "../stores/NativeStore.js"
    
    import { myStreamId, currentCid, joinedRoom } from '../stores/Shared.js'
    
    
    import { channelSettings, updateChannelSettings } from '../stores/ChannelSettings.js'

    import { mdiCog, mdiVolumeHigh, mdiVolumeLow, mdiVolumeMute, mdiVolumeOff, mdiClose } from '@mdi/js'
    
    
    
    import {  Icon, Button } from "svelte-materialify"
    
    
 
    export let showSettings = false
    let videoCapturing = false
    
    export let showHelp

    $: myVolume = $volumes[$myStreamId]
    
    function clickShowSettings() {
    
        if(showSettings == false) {
            // refreshDevices(() => {
                showSettings=true
            // })
        }
    }

  
    function toggleMuted() {
        muted = !muted
    }

    let settings = channelSettings[$myStreamId] || {}

    let {
        muted = true,
    } = settings

  
    $: {
        if($joinedRoom)
            updateChannelSettings($myStreamId, { muted } )
    }


</script>



    <MyVideo volume={myVolume} bind:playing={videoCapturing} />
    
    <div class="mb-5 mr-2 settingsButton" >


        <Button  on:click={clickShowSettings}>
            <Icon path={mdiCog} /> 
            <!-- <VolumeBlob style="width:16px; height:16px; margin-left:10px; display:inline-block" volume={myVolume} /> -->
        </Button>

        
    </div>

    <div class="mb-5 mr-2 muteButton" >


        <Button  on:click={ toggleMuted }>
            {#if muted }
                <Icon path={mdiVolumeOff} style='color:red;'/>
                <!-- <Icon path={mdiVolumeLow} /> <Icon style='color:red; margin-left:-7px; font-weight: bold' path={mdiClose} size={16} />  -->
            {:else }
                <Icon path={mdiVolumeHigh}  /> 
            {/if}
            
        </Button>
        
        
    </div>
    
    <div style="margin-left:auto;margin-bottom:30px" use:tooltip={{text: "Help", style:"margin-left:-60px"}}>
        <Button on:click={()=>showHelp=true}>
            Latency Tips
        </Button>
    </div>




<style>


</style>