<script>
	import { onMount, createEventDispatcher } from 'svelte'

	export let text = ''
	export let style = ''

	const dispatch = createEventDispatcher()
	const closeToolbar = () => dispatch('close')

	let toolbarNode

	onMount(() => {
		toolbarNode.addEventListener('mouseenter', closeToolbar)

		return () => {
			toolbarNode.removeEventListener('mouseenter', closeToolbar)
		}
	})
</script>

{#if text}
	<span class="tooltip" {style} bind:this={toolbarNode}>{text}</span>
{/if}

<style>
	
	@keyframes scaleup {
		from {
			transform: scale(0);
			opacity: 0;
		}
		to {
			transform: scale(1);
			opacity: 1;
		}
	}

	.tooltip {


		font-size: 13px;
		line-height: 20px;
		font-weight: 400;
		font-family: Helvetica, Arial, sans-serif;

		position: fixed;
		margin-left:-53px;
		margin-top:-30px;
		border:1px solid #333;


		background-color: #000;
		color: #ddd;
		border-radius: 10px;
		
		padding: 4px 12px;
		white-space: nowrap;
		z-index: 100;

		animation: scaleup 0.2s;
	}
</style>