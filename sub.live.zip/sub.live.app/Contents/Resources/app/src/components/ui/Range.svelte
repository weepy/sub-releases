<script>

    export let hue
    export let min
    export let max
    export let value
    export let disabled
    export let step
    export let style = ""

</script>

<input class:disabled type="range" style="filter:hue-rotate({hue}deg);{style}" {disabled} {min} {max} {step} bind:value={value} />

<style>

/* Webkit */
input[type=range] {
    -webkit-appearance: none;
    width: 100%;
    border-radius: 8px;
    height: 8px;
    cursor: pointer;
    background-color: rgba(255,0,0,0.6); 
    opacity: 1.0;
}

input[type=range]:focus,
input[type=range]:active {
    outline:0
}

::-webkit-slider-thumb {
    -webkit-appearance: none;
    background-color: rgb(255,0,0);
    border: 0px solid #c7bdbd;
    width: 20px;
    height: 20px;
    border-radius: 16px;
    cursor: pointer;
}

::-webkit-slider-runnable-track {
    /* background: green; */
}

::-webkit-slider-runnable-track:focus,
::-webkit-slider-runnable-track:active {
    outline:0
}

.disabled {
    cursor: none;
}


</style>
