import Tooltip from './Tooltip.svelte'

const tooltip = (node, { text = '', style = '', delay = 300 }) => {
	let component = null
	let isOpened = false
	let isDestroyed = false
	let timer

	function attachTooltip() {

		timer = setTimeout(() => {

			if (!isOpened) {

				// const { left, top, width, height } = node.getBoundingClientRect()
				component = new Tooltip({
					target: node,
					
					props: { text, style },
				})
				isDestroyed = false
				component.$on('close', removeTooltip)
			}
			isOpened = true
		}, delay)

	}

	function removeTooltip() {
		if (isOpened && !isDestroyed) {
			component.$destroy()
			isDestroyed = true
		}

	}

	function onMouseLeave() {
		removeTooltip()
		isOpened = false
		clearTimeout(timer)
	}

	function onMouseClick() {
		onMouseLeave()
	}
	
	// console.log("node.style.position", )
	// node.style.position = node.style.position || "relative"

	node.addEventListener('mouseenter', attachTooltip)
	node.addEventListener('mouseleave', onMouseLeave)
	node.addEventListener('click', onMouseClick)

	return {
		destroy() {
			node.removeEventListener('mouseenter', attachTooltip)
			node.removeEventListener('mouseleave', onMouseLeave)
			node.removeEventListener('click', onMouseClick)
		},
	}
}

export default tooltip