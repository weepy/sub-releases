<script>
import { mdiInformationOutline } from '@mdi/js'
import { Icon } from 'svelte-materialify'

export let text="placeholder"
</script>


<div class="wrapper">
    <Icon size={20} path={mdiInformationOutline} />
    <div class="inner">
        <p>Monitor settings for </p>
        <ul>
            <li>Level</li>
            <li>Pan</li>
            <li>Buffer Size</li>
        </ul>    
    </div>
</div>

<style>

.wrapper {
    position:relative;
    display: inline-block;
}

.inner {
    display: none;
    width: 135px;
    font-size: 12px;
    line-height: 16px;
    height: 105px;
    background: black;
    border: 1px solid #333;
    padding: 10px;
    border-radius: 10px;
    /* margin-left: 100; */
    position: absolute;
    z-index: 1;
    transform: translate(25px, -45px);
}

.wrapper:hover .inner {
    display: block;
}
    
</style>