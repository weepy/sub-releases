<script>
import UserSettings from "./UserSettings.svelte"
import PeerVideo from './PeerVideo.svelte'
import VolumeBlob from './VolumeBlob.svelte'
import Spinner from './ui/Spinner.svelte'
import { mdiVolumeOff, mdiCog, mdiVolumeHigh,mdiClose, mdiVolumeMute } from '@mdi/js'
import { Icon } from 'svelte-materialify'
import {  emitSignal } from "../stores/WebStore.js"
import { fade } from "svelte/transition"
import tooltip from './ui/tooltip.js'

import { channelSettings, updateChannelSettings } from '../stores/ChannelSettings.js'

export let user

export let index
export let stats
export let tof
export let volume


import { volumeToColor } from '../lib/utils.js'

$: badConnection = !stats || stats.missed > 390

let activeSettings

$: username = user.username
$: peer= user.peer

$: borderStyle = badConnection ? "border-color: gray;" : "border-color: " + volumeToColor(volume)

    
let settings = channelSettings[user.sid] || {}
let { muted = false } = settings

$: updateChannelSettings(user.sid, { muted } )

function toggleMuted() {
    muted = !muted
}

</script>

<div class="userpanelwrapper" style="margin-bottom: 40px; margin-right:{index%2 ? 0:40}px">

    <div class="userpanel" class:activeSettings > 

        <div class="container" style={borderStyle}>
            <PeerVideo 
                {peer}
                
                {emitSignal}
                
                nick={username} 
            />

            <UserSettings
                active={activeSettings}
                {user} 
                {stats}
                {volume}
                {tof}
            />

            <span class="close-icon icon" on:click={() => activeSettings = false } >
                <Icon path={mdiClose} size={20}  />
            </span>

            <div class="buttons-row">

                <!-- <h5 class="username" >{user.username}</h5> -->

            <span class="settings-icon icon" on:click={() => activeSettings = true } >
                <Icon path={mdiCog} size={20}  />
            </span>

            <span class="mute-icon icon" on:click={toggleMuted} >
                {#if muted }
                    <Icon path={mdiVolumeOff} style='color:red;'/>
                {:else }
                    <Icon path={mdiVolumeHigh}  /> 
                {/if}
            </span>
        </div>
    </div>
    
</div>
</div>

<style>
.container {
    border-radius: 10px;
    overflow: hidden;
    border-radius: 40px;
    border: 1px solid purple;
    background: black;
    position: relative;
    transition: border-color 0.5s;
}

:global(.s-icon>svg) {
        stroke: #0000007d;

}

.buttons-row {
    display: flex;
    bottom: -20px;
    position:absolute;
    opacity: 0;
    transition: opacity 0.4s;
    width:200px;
    height: 150px;

}

.buttons-row:hover  {
    opacity: 1;
}

.activeSettings .buttons-row {
    opacity: 0 !important;
}

.activeSettings .close-icon  {
    opacity:1;
}

h5 {
    width: 100%;
    font-size: 14px;
    text-align: center;
    margin-top: -60px;
}
.icon:hover {
    transform: scale(1.2,1.2);
    transform-origin: 50%;
    
}

.icon {
    
    cursor: pointer;
    transition: transform 0.3s;
    
}

.close-icon {
    position: absolute;
    top: 15px;
    right: 15px;
    z-index:2;
    opacity: 0;
}

.settings-icon {
    
    position: absolute;
    bottom: 30px;
    left: 65px;
    
}

.mute-icon {
    
    position: absolute;
    bottom: 30px;
    left: 120px;

}

.userpanel {
    position: relative;
}
</style>