<script>
    import { mdiRefresh, mdiInformationOutline, mdiVolumeHigh, mdiVolumeOff, mdiArrowLeftRight, mdiBuffer } from '@mdi/js'
    import Range from './ui/Range.svelte'
    
    import tooltip from './ui/tooltip.js'

    import { Icon, Dialog, Switch } from 'svelte-materialify'
    // import Info from './Info.svelte'

    import AudioDeviceSelect from './AudioDeviceSelect.svelte'  
    import { myStreamId, currentCid, joinedRoom } from '../stores/Shared.js'
    import { channelSettings, updateChannelSettings, getDefaultPan } from '../stores/ChannelSettings.js'
    
    let settings = channelSettings[$myStreamId] || {}

    export let active = false

    let {
        gain = 1.0,
        pan = 0.5, //getDefaultPan(),
        
        buffer = 0
    } = settings

    

    

    $: if($joinedRoom) {
        updateChannelSettings($myStreamId, { pan } ) 
    }
    $: if($joinedRoom) {
        updateChannelSettings($myStreamId, { buffer } ) 
    }
    $: if($joinedRoom) {
        updateChannelSettings($myStreamId, { gain } )
    }
    // $: updateChannelSettings($myStreamId, { muted } )
    
    

  
</script>

<Dialog bind:active={active}>
        
    <div class="pa-5">

    <AudioDeviceSelect />
 
    <div >

        
        <div class="input-wrapper" >
       
            <!-- svelte-ignore a11y-label-has-associated-control -->
            <label>Level</label>
            <Range style="margin-top:15px"  hue={180} min={0} max={2} step={0.01} bind:value={gain} />
            
            
        </div>


        <div class="input-wrapper">
           
            <label>Pan</label>
            <Range style="margin-top:15px"  hue={99} min={0} max={1} step={0.01} bind:value={pan} />
        </div>


        <div class="input-wrapper">
            
            <label>Buffer</label>
            <Range style="margin-top:15px" hue={290} min={0} max={16} step={1} bind:value={buffer} />
            <input type="text" disabled value={buffer}>
        </div>

    </div>

</div>
    
</Dialog>

<style>

    h7 {
        
        padding-top: 20px;
    }
  
  h7 span {
      margin-right: 20px;
  }

    .input-wrapper  {
        display:flex;
        margin-bottom: 18px
    }
    .input-wrapper .icon {

        margin: 0px 10px 0px 0px;
        padding: 5px 10px;
    }


    hr {
    border: 0;
    border-top: 1px solid #444;
    width: 260px;
    margin-left: 25px;
}

    label {
        width: 120px;
    font-size: 12px;
    line-height: 36px;
    /* font-weight: bold; */
    font-family: Helvetica;
}


    input[type=text] {
        border: 1px solid #777;
    width: 22px;
    border-radius: 5px;
    padding: 0;
    text-align: center;
    color: #cacaca;
    font-family: arial;
    margin-left: 10px;
    height: 23px;
    margin-top: 8px;
    font-size: 10px;
    
    }

    
    /* .icon-gain {
        cursor: pointer !important;
        border-radius: 6px;
        border: 1px solid #292929;
    }
    .icon-gain:hover {
       
        border-color: #888;
    } */

    
    
    /* .disabled .icon-gain {
        opacity: 1.0 !important;
         */
    /* } */

</style>