<script>
import { Button, TextField } from 'svelte-materialify'
import { joinChannel } from '../stores/WebStore.js'


let channelId =''

$: disabled = channelId.length != 8

$: channelId = channelId.toUpperCase().replace(/0/g,'O').replace(/[^A-Z1-9]/g, '').slice(0,8)

const recent = LocalStore("visitedChannels") || []

function join() {      
    

    joinChannel(channelId)
}
</script>

<TextField
    bind:value={channelId} 
    style="width:200px"
    placeholder="invite code" autocomplete="off" spellcheck="false" >
    </TextField> 
<Button class="{disabled ? '' : `primary-color`}" on:click={join} {disabled}>Join</Button>





<style>

</style>