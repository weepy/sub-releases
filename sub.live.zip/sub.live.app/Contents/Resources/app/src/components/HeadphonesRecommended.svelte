<script>
import { mdiHeadphones } from '@mdi/js'
import {TextField,Button, Icon} from 'svelte-materialify'

</script>

<h6 class="pt-20 headphones-recommended">
    <Icon path={mdiHeadphones} /> Headphones Recommended
</h6>

<style>

.headphones-recommended {
    background: #000;
    padding: 1px;
    text-align: center;
    font-size: 12px;
    width: 240px;
    margin-left: 135px;
    border-radius: 14px;
    position: fixed;
    bottom: 70px;
    border: 1px solid #555;
    color: #ccc;
}
</style>
