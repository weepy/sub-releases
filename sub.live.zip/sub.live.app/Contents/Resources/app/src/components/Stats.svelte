<script>
export let tof = 0
export let mean = 0
export let dev = null
export let missed = null

</script>

<div class="wrapper">
    
    <div>Latency = {tof == null ? "": tof+"ms"}</div>
    <div>Buffer = {mean}±{dev}</div>
    <div>Lost = {missed == null ? "" : Math.floor(missed/4)+"%"}</div>

</div>

<style>



div {

    font-size: 12px;
    font-family: arial;
    
}

.wrapper {
    width: 100%;
    padding:10px;
    text-align:center;

}


</style>