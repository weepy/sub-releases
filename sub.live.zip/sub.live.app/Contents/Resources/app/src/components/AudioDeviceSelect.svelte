<script>
    import { inputName, outputName, devices, getDevices, changeDevices } from '../stores/DeviceStore.js'
    import { nativeBridge } from "../stores/NativeStore.js"
    import { onMount } from 'svelte';
    
    let outputDevices=[]
    let inputDevices=[]
    
    onMount(() => {
        getDevices()
    })
    
    $: {
        outputDevices=[]
        inputDevices=[]
        $devices.forEach(d => {
            if(d.maxOutputChannels > 0) {
                outputDevices.push({name:d.name, value: d.name})
            }
            if(d.maxInputChannels > 0) {
                inputDevices.push({name:d.name, value: d.name})
            }
        })
    }

    function clickedRefresh() {
        // startCaptureWithDevices()
        getDevices()
        changeDevices()
    }
    

    
    // function removeCompany(name){
    //     const bits = name.split(":")
    //     bits.shift()
    //     return bits.join(":") 
    // }
    
    </script>
    
    <h7 class="mb-2 d-flex" style="margin-bottom: 20px !important">
        <span class="pr-3">Audio Devices</span>
        <button class="refresh" on:click={clickedRefresh}>Refresh</button>
    </h7>
    
    
    <div class="input-wrapper">
    
        <!-- svelte-ignore a11y-label-has-associated-control -->
        <label>Input</label>
    
        <!-- svelte-ignore a11y-no-onchange -->
        <select class="mb-6" bind:value={$inputName} on:change={changeDevices}>
            {#each inputDevices as { name }}
                <option value={name}>{(name)}</option>
            {/each}
        </select>
    
    </div>
    
    <div class="input-wrapper">
    
        <!-- svelte-ignore a11y-label-has-associated-control -->
        <label>Output</label>
    
        <!-- svelte-ignore a11y-no-onchange -->
        <select class="mb-6" bind:value={$outputName} on:change={changeDevices}>
            {#each outputDevices as { name }}
                <option value={name}>{(name)}</option>
            {/each}
    
        
        </select>
    
    </div>
    
        
    
    
    
    <style>
    
    .input-wrapper {
        display:flex;
        margin-bottom: 18px   
    }
    
    
    button {
        outline:none;
        font-size: 12px;
        border: 1px solid #444;
        border-radius: 20px;
        padding: 0px 11px;
        text-transform: lowercase;
        margin-left: 110px;
        border: 2px solid #6200ee;
        background: transparent!important;
        
    }
    
    .input-wrapper select {
        color: white;
        width: 220px;
        padding: 7px 0px;
        border-bottom: 1px solid #aaa !important;
        border-radius: 0;
        outline:none;
        -webkit-appearance: none !important;
        font-size: 14px !important;
    
        background: transparent;
        background-image: url("data:image/svg+xml;utf8,<svg fill='white' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>");
        background-repeat: no-repeat;
        background-position-x: 100%;
        background-position-y: 5px;
    }
    
    label {
            width: 70px;
            color: white;
        font-size: 12px;
        line-height: 36px;
        /* font-weight: bold; */
        font-family: Helvetica;
    }
    
    </style>