<script>
export let volume = -140

export let style=""
let volumeColor = "rgb(0,0,0)"


$: {
    let x = (volume+50)/50
    
    if(x < 0) {
        volumeColor = `rgb(0,0,0)`    
    }
    else if (x < 0.5) {
        volumeColor = `rgb(0,${x/0.5*255},0)`    
    }
    else if(x < 1) {
        volumeColor = `rgb(${(x-0.5)/0.5*255},255,0)`
    }
    else {
        volumeColor = `rgb(255,0,0)`
    }
    
    
    // volumeColor = `rgb(0,${x},0)`
}

</script>
<div class="volume" style="{style};background-color:{volumeColor}"></div>

<style>


.volume {
    background-color: #000;
    width:100%;
    height:100%;

    border-radius: 20px;
    
    transition: background-color 0.1s;
    

}
</style>