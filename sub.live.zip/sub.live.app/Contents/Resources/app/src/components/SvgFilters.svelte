<filter id="pink-acid" x="-10%" y="-10%" width="120%" height="120%" filterUnits="objectBoundingBox" primitiveUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
	<feColorMatrix type="matrix" values=".33 .33 .33 0 0
            .33 .33 .33 0 0
            .33 .33 .33 0 0
            0 0 0 1 0" in="SourceGraphic" result="colormatrix"/>
	<feComponentTransfer in="colormatrix" result="componentTransfer">
    		<feFuncR type="table" tableValues="1 0.98 0.1"/>
		<feFuncG type="table" tableValues="0.17 1 0.82"/>
		<feFuncB type="table" tableValues="0.7 0.84 0.67"/>
		<feFuncA type="table" tableValues="0 1"/>
  	</feComponentTransfer>
	<feBlend mode="normal" in="componentTransfer" in2="SourceGraphic" result="blend"/>
</filter>

<svg width="10" height="10" viewBox="0 0 10 10">
    <clipPath id="squircle" clipPathUnits="objectBoundingBox">
        <path
        fill="red"
        stroke="none"
        d="M 0,0.5 C 0,0 0,0 0.5,0 S 1,0 1,0.5 1,1 0.5,1 0,1 0,0.5"
        />
    </clipPath>
</svg>


      <filter id="epic-triple">
          <feColorMatrix 
              in="SourceGraphic"
              type="saturate" 
              values="3"
              result="saturateOUT"
          />

          <feColorMatrix 
              in="saturateOUT"
              type="hueRotate" 
              values="45"
              result="hueOUT"
          />

          <feConvolveMatrix 
              in="hueOUT" 
              order="3" 
              preserveAlpha="true" 
              kernelMatrix="-1 0 0 0 4 0 0 0 -1"
              result="sharpenOUT"
          />

      </filter>

      <filter id="clarendon"
      color-interpolation-filters="sRGB"
      filterUnits="objectBoundingBox"
      primitiveUnits="objectBoundingBox"
      x="0" y="0" width="100%" height="100%">
  <!-- contrast -->
  <feComponentTransfer>
      <feFuncR type="linear" slope="1.2" intercept="-0.1"/>
      <feFuncG type="linear" slope="1.2" intercept="-0.1"/>
      <feFuncB type="linear" slope="1.2" intercept="-0.1"/>
  </feComponentTransfer>
  <!-- saturate -->
  <feColorMatrix result="cs" type="saturate" values="1.35"/>
  <feFlood flood-color="rgba(127, 187, 227, 0.2)"/>
  <feBlend mode="overlay" in2="cs" />
</filter>


<filter id="pixelate" x="0%" y="0%" width="100%" height="100%">
    <!--Thanks to Zoltan Fegyver for figuring out pixelation and producing the awesome pixelation map. -->
    <feGaussianBlur stdDeviation="2" in="SourceGraphic" result="smoothed" />
    <feImage width="15" height="15" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAIAAAACDbGyAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAWSURBVAgdY1ywgOEDAwKxgJhIgFQ+AP/vCNK2s+8LAAAAAElFTkSuQmCC" result="displacement-map" />
    <feTile in="displacement-map" result="pixelate-map" />
    <feDisplacementMap in="smoothed" in2="pixelate-map" xChannelSelector="R" yChannelSelector="G" scale="50" result="pre-final"/>
    <feComposite operator="in" in2="SourceGraphic"/>
  </filter>

  <filter id="pixelate2" x="0" y="0">
    <feFlood x="4" y="4" height="2" width="2"/>
    
    <feComposite width="10" height="10"/>
    
    <feTile result="a"/>
    
    <feComposite in="SourceGraphic" in2="a" 
                 operator="in"/>
    
    <feMorphology operator="dilate"
                  radius="5"/>
  </filter>

  <filter id="posterize">
    <feComponentTransfer>
    <feFuncR type="discrete" tableValues="0 .5 1" />
    <feFuncG type="discrete" tableValues="0 .5 1" />
    <feFuncB type="discrete" tableValues="0 .5 1" />
    </feComponentTransfer>
   </filter>

