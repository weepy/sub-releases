<script>
    import { mdiCog, mdiVolumeHigh, mdiArrowLeftRight, mdiBuffer } from '@mdi/js'
     

    import Range from './ui/Range.svelte'
    import Spinner from './ui/Spinner.svelte'

    
    import Stats from  './Stats.svelte'
    export let user

    
    export let stats = {}

    export let active = false

    
    export let tof = null
    
    import { channelSettings, updateChannelSettings, getDefaultPan } from '../stores/ChannelSettings.js'
    
    let settings = channelSettings[user.sid] || {}

    let {
        gain = 1.0,
        pan = getDefaultPan(user),
        // muted = false,
        buffer = 5
    } = settings



    $: updateChannelSettings(user.sid, { pan } ) 
    $: updateChannelSettings(user.sid, { buffer } ) 
    $: updateChannelSettings(user.sid, { gain } )



    // $: disabled = muted

   
    
    let showBadconnection = stats.missed == null || stats.missed >= 400
    
    showBadconnection = false
    </script>
    
    

    <div class:active class="settings-wrapper" >

       
        <h5 class="username" >{user.username}</h5>
        

            
  

            <div class="slider-wrapper" >
                <!-- svelte-ignore a11y-label-has-associated-control -->
                <label>Level</label>
                <Range style="margin-top:15px" hue={180} min={0} max={2} step={0.01} bind:value={gain} />
            </div>
    
    
            <div class="slider-wrapper">
                <!-- svelte-ignore a11y-label-has-associated-control -->
                <label>Pan</label>
                <Range style="margin-top:15px" hue={99} min={0} max={1} step={0.01} bind:value={pan} />
            </div>


            <div class="slider-wrapper">
                
                <!-- svelte-ignore a11y-label-has-associated-control -->
                <label style="margin-right:13px">Buffer</label>
                <Range style="margin-top:15px" hue={290} min={0} max={16} step={1} bind:value={buffer} />
                <input type="text" disabled value={buffer}>
            </div> 

            {#if showBadconnection } 
                <p>Waiting for audio <Spinner style="width: 13px;
                    margin-left: 7px;
                    color: gray;
                    margin-top: 4px;" /></p> 
                
            {:else}

                <div class="stats">
                    <div>Lag={tof == null? "??": tof+"ms"}</div>
                    <div>Buffer={stats.mean==null?"??": stats.mean+"±"+stats.dev}</div>
                    <div>Lost={stats.missed == null ? "??" : Math.floor(stats.missed/4)+"%"}</div>
                </div>
            {/if}

       
    </div>
    
    
    
    <style>



        p {
            font-size: 12px;
    padding: 5px;
    text-align: center;
    
        }
    .settings-wrapper {
        background: #111;

        height: 200px;
        z-index:1;
        

        padding: 13px;
        padding-top: 40px ;

        position:absolute;
        top: 0px;
        left:0px;
        width: 200px;
        display: none;
    }
    h5 {
        text-align: center;
    padding-bottom: 10px;
    font-size: 14px;
    position: absolute;
    width: 174px;
    top: 10px;
}
    
    h6 {
        text-align: center;
    font-size: 14px;
    color: #aaa;
    line-height: 19px;
    margin-bottom: 24px;
    margin-top: 12px;
    }
    .active {
        display: block;
    }
    
    label {
        width: 60px;
        font-size: 12px;
        line-height: 37px;
        /* font-weight: bold; */
        font-family: Helvetica;
    }


    .slider-wrapper  {
        display:flex;

        /* padding:10px; */
    }
   
    .stats {
        width: 174px;
        font-size: 12px;
        margin-top:4px;
        text-align: center;
    }
    .stats div {
        display: inline-block;
        font-size: 11px;
        
    }
    input[type=text] {
        border: 1px solid #777;
    width: 22px;
    border-radius: 5px;
    padding: 0;
    text-align: center;
    color: #cacaca;
    font-family: arial;
    margin-left: 10px;
    height: 23px;
    margin-top: 8px;
    font-size: 10px;
    }

   

  
    
    </style>