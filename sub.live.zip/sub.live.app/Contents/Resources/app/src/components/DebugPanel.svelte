<script>
    import { Dialog} from 'svelte-materialify'
    import { tcpState } from '../stores/WebStore.js'

    import { currentUser } from '../stores/Shared.js'
    import { udpAddress } from '../stores/NativeStore.js'

    export let showDebug = false



    let version = () => config && config.version
    let packaged = () => config && config.packaged
</script>


<Dialog bind:active={showDebug}>
<div style="background:#343c44; text-align: center" class="pa-5"  >
    <h7>Debug Info</h7>
    <p> Version: { version() } - { packaged() ? "production" : "dev"} </p>
    <p> User: {$currentUser ? JSON.stringify($currentUser) : "None"}</p>
    <p> TCP: {$tcpState} </p>
    <p> UDP: {$udpAddress} </p>

</div>

</Dialog>