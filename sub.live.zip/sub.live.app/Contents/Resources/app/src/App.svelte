
<script>
	import { udpAddress } from './stores/NativeStore.js'
	import { currentUser, currentCid } from "./stores/Shared.js"
	
	import Layout from './pages/Layout.svelte'
	import FrontPage from './pages/FrontPage.svelte'
	import ChooseChannelPage from './pages/ChooseChannelPage.svelte'

	import ChannelPage from './pages/ChannelPage.svelte'

	import Alert from './components/Alert.svelte'
	
	import config from "./config.js"
	
	function handleKeydown(e) {
		if(e.key == "r" && e.metaKey)
			document.location.reload()
	}
	
	$: {
		if($currentUser && config.TRACKING) {
			const uid = $currentUser.username+"-"+$currentUser.sid.toString(36)
			mixpanel.identify(uid)
			console.log("mixpanel.identify", uid )
		}

	}

	track("boot", config)




	</script>
	
	<Layout>
		

		{#if !$currentUser} 
			<FrontPage />
		{:else if $currentCid }

			<ChannelPage />
		
		 {:else if $udpAddress}
			<ChooseChannelPage />
		{:else }
			<p>Locating ...</p>
		{/if}

		<Alert /> 

	
	</Layout>

	<svelte:window on:keydown={handleKeydown}/>

		
