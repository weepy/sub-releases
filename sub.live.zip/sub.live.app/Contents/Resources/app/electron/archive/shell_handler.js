const { ipcMain } = require("electron")
const ShellBridge = require('./ShellBridge.js')

let shell

let mainWindow 
let config

const sendToWindow = (args) => {
    console.log(">>", ...args)
    if(!mainWindow.isDestroyed())
      mainWindow.webContents.send("shellResponse", args)
}

ipcMain.on('bootShell', (IpcMainEvent, arg) => {
  console.log(arg) // prints "ping"
  

  if(shell) {
    shell.die()
    shell = null
  }
    
  const gccDebugFilename = `${__dirname}/../../sub-shell/bin/sub-shell`
  const debugShellPath = `${__dirname}/../../sub-shell/DerivedData/sub-shell/Build/Products/Debug/sub-shell`
  const packagedShellPath = process.resourcesPath + "/sub-shell"
    

  const { app } = require('electron')

  const shellPath = app.isPackaged ? packagedShellPath : debugShellPath

  // sendToWindow(["PATHS",process.resourcesPath, app.getAppPath(), __dirname])
  console.log("trying to open shell at ", shellPath)
  
  shell = ShellBridge(shellPath, (data) => {
    sendToWindow(data)
  })
  
  
})

module.exports = (_win, _config) => {
  mainWindow = _win
  config = _config
}