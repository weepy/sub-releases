// window.ipcRenderer = require('electron').ipcRenderer;

// console.log("ipcRenderer",window.ipcRenderer, window)
// window.hello="123"



// preload.js
const { contextBridge, ipcRenderer } = require('electron')


contextBridge.exposeInMainWorld('electron', {

    bootShell(data) { 
        console.log(">>", JSON.stringify(data))
        ipcRenderer.send('bootShell', data) 
    },
    onShellResponse(fn) {
        ipcRenderer.on("shellResponse", (event, arg) => {
            fn(arg)
        })    
    }
})  