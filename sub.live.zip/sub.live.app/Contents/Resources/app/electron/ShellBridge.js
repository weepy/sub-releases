const child_process = require('child_process');


function Liner(output) {

    let cache = ''
    const liner = (data) => {

        cache = cache + data.toString()

        const lines = cache.split("\n")
        cache = lines.pop()

        lines.forEach((line) => {
            if(line == "") return

            let o
            try {
                o = JSON.parse(line)
                
            }
            catch(e) {
                console.error("FAILED PARSING JSON: `" + line+ "`")
            }

            output(o)
        })
    }

    return liner
}


module.exports = function ShellBridge(filename, event_handler) {
    console.log("opening shell",filename)
    const liner = Liner(event_handler)

    const shell = child_process.spawn(filename, ["stdin=1"], {})    
    shell.on('error', err => {
        console.error(err)
    })
    
    shell.on('close', (code) => {
        console.info('shell process exited with code=', code)

        if(!shell._dying) {
            event_handler(["DIED", code]) 
        }
        
    })


    shell.stdout.on('data',  (data) => {
        liner(data)
    })

    shell.stderr.on('data',  (data) => {
        console.info(data.toString())
    })
    
    function send(arg) {
        const msg = JSON.stringify(arg)
        shell.stdin.write(msg+"\n")
    }
    console.info('shell process opened?')

    
    return {
        send,
        die() {
            shell._dying = true
            shell.kill()
        }
    }
}