// window.ipcRenderer = require('electron').ipcRenderer;

// console.log("ipcRenderer",window.ipcRenderer, window)
// window.hello="123"



// preload.js
const { contextBridge, ipcRenderer } = require('electron')


contextBridge.exposeInMainWorld('electron', {

    request(data) { 
        console.log(">>", JSON.stringify(data))
        ipcRenderer.send('request', data) 
    },
    onResponse(fn) {
        ipcRenderer.on("response", (event, arg) => {
            if(arg[0] != "VOLUMES" && arg[0] != "STATS")
                console.log(">>" , arg)
            fn(arg)
        })    
    }
})  