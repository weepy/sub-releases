
<script>
	
	import Layout from './pages/Layout.svelte'

	
	// function handleKeydown(e) {
	// 	if(e.key == "r" && e.metaKey)
	// 		document.location.reload()
	// }
	


	</script>


	<Layout>
		
HI

	
	</Layout>

	<!-- <svelte:window on:keydown={handleKeydown}/> -->
