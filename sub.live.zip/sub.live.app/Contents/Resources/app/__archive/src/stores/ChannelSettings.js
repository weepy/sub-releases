import { currentCid } from "./Shared.js"
import { nativeBridge } from '../stores/NativeStore.js'

import config from '../config.js'

let currentKey
 
export let channelSettings = null

currentCid.subscribe(cid => {

    if(!cid) {
        channelSettings = null
        currentKey = null
    }
    else {

        currentKey = config.NAMESPACE + "_" + "channelSettings:"+cid
        try {
            channelSettings = JSON.parse(localStorage[currentKey])
        }
        catch(e) {
            channelSettings = {}
        }

        
    }
})


export function updateChannelSettings(sid, o) {

    let cur = channelSettings[sid] = channelSettings[sid] || {}

    for(let i in o) {
        cur[i] = o[i]
    }
    
    localStorage[currentKey] = JSON.stringify(channelSettings)

    nativeBridge.send("SET_STREAM", Object.assign({sid}, o))
}