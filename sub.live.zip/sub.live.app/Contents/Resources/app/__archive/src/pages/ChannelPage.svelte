<script>
import { onMount} from "svelte"

import tooltip from '../components/ui/tooltip.js'
import MyVideo from '../components/MyVideo.svelte'
import VolumeBlob from '../components/VolumeBlob.svelte'

import {  volumes, stats, tofs, copyNative, nativeBridge} from "../stores/NativeStore.js"
import {  leaveChannel } from "../stores/WebStore.js"
import { devices, currentCid, inputName, outputName, channelUsers, myStreamId } from '../stores/Shared.js'

import MySettings from '../components/MySettings.svelte'



import UserPanel from '../components/UserPanel.svelte'




import { mdiAccountPlus, mdiCog, mdiTuneVariant, mdiHelp, mdiExitToApp} from '@mdi/js'

import AudioStreamControl from '../components/AudioStreamControl.svelte'


import { Dialog, Icon, Button } from "svelte-materialify"


$: if($currentCid) {
    

    let visited = (LocalStore("visitedChannels")||[])

    visited = visited.filter( cid => cid != $currentCid)
    visited.unshift($currentCid)

    LocalStore.set("visitedChannels", visited)
}

let myStream


onMount(() => {
    let startTime = Date.now()
    track("ChannelPage", {"channel": $currentCid })

    // refreshDevices()

    return (() => {
        let seconds = (Date.now()-startTime)/1000
        
        track("SessionDuration", { channel: $currentCid, seconds })
    })
})


function copyInvite() {
    copyNative($currentCid)
    alert("<p>To invite someone to this channel, give them this code: <br/><br/> <code>" + $currentCid + "</code> <br/><br/> This has been copied to your clipboard.")
}

let showSettings = false
let showHelp = false

let otherUsers = []

$: otherUsers = $channelUsers.filter(u => u.sid != $myStreamId)


let videoCapturing = false

$: myVolume = $volumes[$myStreamId]


function doLeaveChannel() {
    nativeBridge.send("STOP_CAPTURE")
    leaveChannel() // web
}


function clickShowSettings() {
    
    if(showSettings == false) {
        // refreshDevices(() => {
            showSettings=true
        // })
    }
}
</script>

{#if $currentCid}
    <h4 class="mb-5 d-flex">
        <span class="channelId">#{$currentCid.split("#")[0]}</span>
            
        
        <div style="margin-right:20px; margin-left: auto" use:tooltip={{text: "Invite",style:"margin-left:-60px"}}>
        <Button  on:click={copyInvite}>
            <Icon path={mdiAccountPlus} /> 
    
        </Button>
        </div>

        <div use:tooltip={{text: "Leave Channel", style:"margin-left:-80px"}}>
            <Button on:click={doLeaveChannel} ><Icon path={mdiExitToApp}/></Button>
        </div>

    </h4>

    
    <div class="mb-5">
        
        <div class="users">
            {#each otherUsers as user, index (user.sid)}
            
                <div class="userpanelwrapper" style="margin-bottom: 40px; margin-right:{index%2 ? 0:40}px">
                    <UserPanel 
                        {user} 
                        {myStream}
                        stats={$stats[user.sid]}
                        volume={$volumes[user.sid]} 
                        tof={$tofs[user.sid]}
                    />
                </div>
            
            {/each}

            {#if otherUsers.length == 0} 
                <!-- svelte-ignore a11y-distracting-elements -->
                <p>
                    Waiting for other users ...    
                </p>
                
            {/if}
        </div>
        
        
    </div>

    <div class="mypanel d-flex" style="width:520px">

        <MyVideo emitStream={(s) => myStream = s} bind:playing={videoCapturing} />
        
        <div class="mb-5 settingsButton" >

   
            <Button  on:click={clickShowSettings}>
                <Icon path={mdiTuneVariant} /> 
                <VolumeBlob style="width:16px; height:16px; margin-left:10px; display:inline-block" volume={myVolume} />
            </Button>
    
            
        </div>
        
        <div style="margin-left:auto;margin-bottom:30px" use:tooltip={{text: "Help", style:"margin-left:-60px"}}>
            <Button on:click={()=>showHelp=true}>
                Latency Tips
            </Button>
        </div>
    </div>

    
    <MySettings bind:active={showSettings}/>

    <Dialog bind:active={showHelp}>
            
        <div class="pa-5 tips">
            <h5>Tips to improve latency</h5>
            <br/>
            <ul> 
                <li>People closer will have lower latency</li>
                <li>Use ethernet rather than Wifi</li>
                <li>Use wired headphones</li>
                <li>Some ISP packages have better connections</li>
                <li>Lower buffer => lower latency, but too low and you will get dropouts</li>
                <li>Close other network hungry apps [e.g browers]</li>
            </ul>
            <br/>
            <Button class="primary-color" on:click={() => showHelp = false}>OK</Button>
        </div>
    </Dialog>

    <AudioStreamControl devices={$devices} inputName={$inputName} outputName={$outputName} />

{:else}
    <p>Leaving..</p>
{/if}




<style>
.tips li {
    font-size: 13px;
    line-height: 30px;
    font-family: Helvetica;
}
.users {
    display: flex;
    flex-wrap: wrap;
}

.waiting {
    /* animation: fadeIn 10s; */
}

@keyframes fadeIn {
    0% {opacity:0;}
    100% {opacity:1;}
}

.mypanel {
    align-items: center;
    /* justify-content: center; */
    position: absolute;
    bottom: 0px;
    
    height: 170px;
    width: 100%;
}



.channelId {
    user-select: text;
    --webkit-user-select: text;
    cursor: text;
}

</style>