import App from './App.svelte'

import * as Sentry from "@sentry/browser";
import { Integrations } from "@sentry/tracing";
import config from "./config.js"


window.track = (a,b,c) => {
  
  if(config.TRACKING) {
    console.log("mixpanel track", a,b,c)
    mixpanel.track(a,b,c)
  }
}



window.onbeforeunload = () => {
  track("unload")
}

if(config.TRACKING) {
  Sentry.init({
    dsn: "https://a422dad0cc184c48a54269671fc5ea26@o538036.ingest.sentry.io/5655979",
    integrations: [new Integrations.BrowserTracing()],
    tracesSampleRate: 1.0,
  })
}

const app = new App({
	target: document.body
})

export default app 