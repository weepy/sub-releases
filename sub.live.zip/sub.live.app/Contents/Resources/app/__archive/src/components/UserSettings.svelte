<script>
    import { mdiCog, mdiVolumeHigh, mdiArrowLeftRight, mdiBuffer } from '@mdi/js'
     
    import tooltip from './ui/tooltip.js'
    import Range from './ui/Range.svelte'


    import { Slider, Icon } from 'svelte-materialify'
    
    
    import Stats from  './Stats.svelte'
    export let user
    
    export let stats = {}

    export let active = false

    let disabled = false
    
    export let tof = null
    
    import { channelSettings, updateChannelSettings } from '../stores/ChannelSettings.js'
    
    let settings = channelSettings[user.sid] || {}

    let {
        gain = 1.0,
        pan = 0.5,
        muted = false,
        buffer = 5
    } = settings

    $: updateChannelSettings(user.sid, { pan } ) 
    $: updateChannelSettings(user.sid, { buffer } ) 
    $: updateChannelSettings(user.sid, { gain } )
    $: updateChannelSettings(user.sid, { muted } )
    
    // $: monitoring = !muted

    $: disabled = muted


    </script>
    
    

    <div class:active class="settings-wrapper" >



        <div class="slider-wrapper" >
            <!-- <div class="icon" use:tooltip={{text:"Volume"}}>
                <Icon path={mdiVolumeHigh} size={20} />
            </div> -->

            <label>Level</label>

            <Range style="margin-top:15px" hue={180} min={0} max={2} step={0.01} bind:value={gain} />
            
        </div>


        <div class="slider-wrapper">
            <!-- <div class="icon" use:tooltip={{text:"Pan"}}>
                <Icon path={mdiArrowLeftRight} size={20} />
            </div> -->

            <label>Pan</label>
            <Range style="margin-top:15px" hue={99} min={0} max={1} step={0.01} bind:value={pan} />
        </div>


        <div class="slider-wrapper">
            <!-- <div class="icon" use:tooltip={{text:"Buffer Size"}}>
                <Icon path={mdiBuffer} size={20} />
            </div> -->
            <label style="margin-right:13px">Buffer</label>
            <Range style="margin-top:15px" hue={290} min={0} max={16} step={1} bind:value={buffer} />
            <input type="text" disabled value={buffer}>
        </div> 


        
        <Stats {...stats} {tof} />
       
    </div>
    
    
    
    <style>
    .settings-wrapper {
        background: #111;
        overflow: hidden;
        height: 180px;
        border-radius: 10px;
        padding: 13px;

        position:absolute;
        top: 0;
        width: 240px;
        display: none;
    }
    .active {
        display: block;
    }
    
    label {
        width: 60px;
        font-size: 12px;
        line-height: 30px;
        /* font-weight: bold; */
        font-family: Helvetica;
    }


    .slider-wrapper  {
        display:flex;
        margin-bottom: 12px
    }
   

    input[type=text] {
        border: 1px solid #777;
    width: 22px;
    border-radius: 5px;
    padding: 0;
    text-align: center;
    color: #cacaca;
    font-family: arial;
    margin-left: 10px;
    height: 23px;
    margin-top: 8px;
    font-size: 10px;
    }

    .disabled {
        /* filter: saturate(0); */
        opacity: 0.6;
    }

  
    
    </style>