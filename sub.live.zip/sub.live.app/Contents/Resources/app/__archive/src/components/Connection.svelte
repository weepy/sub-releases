<script>
import { tcpState } from '../stores/WebStore.js'
import { udpAddress } from '../stores/NativeStore.js'
import { Icon } from 'svelte-materialify'

let state = ''

$: {
    if($tcpState == "connected") {
        if($udpAddress) {
            state = "online"
        }
        else {
            state = "locate"
        }

    }
    else {
        state = "offline"
    }
}

</script>


<div> 
    {#if state == "offline"}
    <Icon class="mdi mdi-thumb-up" /> 
    {/if}


    <div style="width:70px"> <span class="light {state}"></span> {state} </div>

    
</div>

<style>
.light {
    width:10px;height:10px; display:inline-block;
    background:gray;border-radius:10px;

}

.light.online {
    background:white;
}
.light.locating {
    background:grey;
}
div {
    display : inline-block;
    margin: 0 30px;
}
</style>

    
