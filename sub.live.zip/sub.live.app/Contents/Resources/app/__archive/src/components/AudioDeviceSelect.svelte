<script>
import { Select,Icon } from 'svelte-materialify'
import { inputName, outputName, devices } from '../stores/Shared.js'
import { mdiArrowLeftThick, mdiArrowRightThick, mdiRefresh } from '@mdi/js'
import tooltip from './ui/tooltip.js'
import { onMount } from "svelte"
import { get } from "svelte/store"

import { nativeBridge} from "../stores/NativeStore.js"
let outputDevices=[]
let inputDevices=[]

$: {
    outputDevices=[]
    inputDevices=[]
    $devices.forEach(d => {
        if(d.maxOutputChannels > 0) {
            outputDevices.push({name:d.name, value: d.name})
        }
        if(d.maxInputChannels > 0) {
            inputDevices.push({name:d.name, value: d.name})
        }
    })
}

function updateDevices() {
    
    nativeBridge.send("AUDIO_SESSION_SET_DEVICES", {inputName:$inputName, outputName: $outputName})
}

function setInputValue(e) {
    console.log(e, inputDevices, $inputName)
}

function refreshDevices() {
    
    const a = get(inputName)
    const b = get(outputName)
    nativeBridge.send("AUDIO_SESSION_INIT", {inputName:a, outputName: b})
}

</script>

<h7 class="mb-2 d-flex" style="margin-bottom: 20px !important">
    <span class="pr-3">Audio Devices</span>
    <button class="refresh" on:click={refreshDevices}>Refresh</button>
</h7>



<!-- <div class="input-wrapper2" style="background:green">
    <label>Test</label>

    <select class="mb-6" >
    
        <option>name</option>


    </select>

</div> -->

<div class="input-wrapper">

    
    
    <!-- svelte-ignore a11y-label-has-associated-control -->
    <label>Input</label>

    <!-- svelte-ignore a11y-no-onchange -->
    <select class="mb-6" bind:value={$inputName} on:change={updateDevices}>
        {#each inputDevices as { name }}
            <option>{name}</option>
        {/each}

    
    </select>

</div>

<div class="input-wrapper">

    <!-- svelte-ignore a11y-label-has-associated-control -->
    <label>Output</label>


    <!-- svelte-ignore a11y-no-onchange -->
    <select class="mb-6" bind:value={$outputName} on:change={updateDevices}>
        {#each outputDevices as { name }}
            <option>{name}</option>
        {/each}

    
    </select>

</div>

    



<style>

.input-wrapper {
    display:flex;
    margin-bottom: 18px   
}


button {
    outline:none;
    font-size: 12px;
    border: 1px solid #444;
    border-radius: 20px;
    padding: 0px 11px;
    text-transform: lowercase;
    
}

.input-wrapper select {
	color: white;
    width: 220px;
	padding: 7px 0px;
	border-bottom: 1px solid #aaa !important;
    border-radius: 0;
	outline:none;
	-webkit-appearance: none !important;
	font-size: 14px !important;

    background: transparent;
    background-image: url("data:image/svg+xml;utf8,<svg fill='white' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>");
    background-repeat: no-repeat;
    background-position-x: 100%;
    background-position-y: 5px;
}

label {
        width: 70px;
        color: white;
    font-size: 12px;
    line-height: 36px;
    /* font-weight: bold; */
    font-family: Helvetica;
}

</style>