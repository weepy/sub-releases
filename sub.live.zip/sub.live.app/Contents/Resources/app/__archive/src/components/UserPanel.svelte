<script>
import UserSettings from "./UserSettings.svelte"
import PeerVideo from './PeerVideo.svelte'
import VolumeBlob from './VolumeBlob.svelte'
import Spinner from './ui/Spinner.svelte'
import { mdiTuneVariant } from '@mdi/js'
import { Icon } from 'svelte-materialify'
import {  emitSignal } from "../stores/WebStore.js"
import { fade } from "svelte/transition"
import tooltip from './ui/tooltip.js'

export let user
export let myStream
export let stats
export let tof
export let volume


$: badConnection = !stats || stats.missed > 390

let activeSettings

$: username = user.username
$: peer= user.peer

</script>

<div class="userpanel" class:activeSettings> 

        

    <PeerVideo 
        {peer}
        {myStream} 
        {emitSignal}
        nick={username[0].toUpperCase()} 
    />

        

    <UserSettings
        active={activeSettings}
        {user} 
        {stats}
        {volume}
        {tof}
    />

    <div class="user-row">
        <div class="volume-spinner-wrapper">
            {#if badConnection }
                <div use:tooltip={{text:"Waiting for audio"}} >
                    <Spinner style="color:white" />
                </div>
            {:else }
                <VolumeBlob {volume}/>
            {/if}
            
        </div>
        <div class="username">            
            {username}
        </div>
        <div class="settings-icon" on:click={() => activeSettings = !activeSettings} >
            <Icon path={mdiTuneVariant} size={16} style="cursor: pointer;" />
        </div>
    </div>
</div>

<style>
.volume-spinner-wrapper {
    width: 12px;
    height: 12px;
    /* position: absolute; */
    margin-left:5px;
    margin-right:5px;
    
}

.user-row {
    display:flex;
    align-items:baseline;
    padding: 5px;
}

.settings-icon {
    margin-left: auto;
    margin-right:5px;
}
.userpanel {
    width:240px; 
    border-radius: 10px; 
    /* border:1px solid #666; */
    background: #333;
    /* box-shadow: 0px 0px 0px 1px #000; */
    /* margin-bottom:20px; */
    position: relative;
}
</style>