<script>
import { onDestroy } from 'svelte'
import { fade } from 'svelte/transition'



export let myStream
export let peer

export let emitSignal
export let nick = "@"

let video

let addedStream

$: {
    if(myStream) {
        if(!addedStream) {
            peer.addStream(myStream)
            addedStream = myStream
        }
    }
    else {
        if(addedStream) {
            peer.removeStream(addedStream)
            addedStream = null
        }   
    }
}

onDestroy(() => {
    peer.destroy()
})



peer.on('signal', signal => {
    
    emitSignal(peer.sid, signal)
})


peer.on('stream', stream => {
    console.log("peer stream")

    video.muted = true
    video.autoplay = true
    video.playsinline = true
    video.srcObject = stream
    

    stream.getTracks().forEach(track => {
        track.addEventListener('mute', () => {
            video.srcObject = null 
        })
    })

})

peer.on('connect', () => {
    console.log("peer connect")
})

peer.on('data', (data) => {
    console.log("peer data")
})

peer.on('close', () => {
    console.log("peer close")
})

peer.on('error', err => {
    console.log('peer error', err)
})



</script>


<div >
    <h5>{nick}</h5>
    
    <!-- svelte-ignore a11y-media-has-caption -->
    <video bind:this={video} />
    
   
</div>

<style>

video {
        width: 100%;
    height: 100%;
    border-radius: 10px;
    
    position: absolute;
    top:0;
    
  
}

h5 {
    width:240px;
    text-align:center;
    margin-top: 80px;
}

div {
    width: 240px;
    height: 180px;
    position: relative;
    border-radius: 9px;
    overflow:hidden;
    background: black;
    
    
}
</style>