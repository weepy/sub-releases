<script>
import { mdiVideo, mdiVideoOff } from '@mdi/js'
import { Icon } from "svelte-materialify"
import Spinner from './ui/Spinner.svelte'

export let emitStream

let myVideo
let myStream
let streamStarting

import config from '../config.js'

const [platform, major, minor, patch] = config.OS.split(".")
let disabledVideo = major < 10 || (major == 10 && minor < 14)


$: {
    if(myVideo) {
        myVideo.pause()
        myVideo.srcObject = myStream
        
        if(myStream) {
            myVideo.muted = true
            myVideo.play()
        }
    }
}

function startCapture() {


    streamStarting = true

    navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { width: 120, height: 90, frameRate:10 }
    })
    .then(s => {
        myStream = s
        streamStarting = false
        
        emitStream(myStream)


    })
    .catch((err) => {
        console.log("ERROR", err) 
        streamStarting = false
    })

}

function stopCapture() {
    const tracks = myStream.getTracks()

    tracks.forEach(function(track) {
        track.stop();
    })
    myStream = null
    emitStream(myStream)
    
}

export let playing = false

$: {
    if(playing) {
        startCapture()
    }
}
$: {
    if(!playing) {
        if(myStream) {
            stopCapture()
        }
    }
}

let showStopIcon = false

function handleMouseOver() {
    if(playing) {
        showStopIcon = true
    }
}

function handleMouseOut() {
    showStopIcon = false
}

function toggleCapture() {

    if(disabledVideo) {

        alert("Sorry, video capture needs Macos Mojave 10.14 or later 😢. You are running " + config.OS)
        return
    }
    playing = !playing
    
    track(playing ? "camOn" : "camOff")
}

</script>

<div class="wrapper" class:disabledVideo class:noStream={!myStream} on:click={toggleCapture} on:mouseenter={handleMouseOver} on:mouseout={handleMouseOut}>
    <!-- svelte-ignore a11y-media-has-caption -->
    <video bind:this={myVideo} />

        <div >
            {#if !playing }
                <Icon path={mdiVideo} />
            {:else if !myStream }
                <Spinner style="width:20px;color:white;margin-top:-7px" />
            {:else if showStopIcon}
                <Icon path={mdiVideoOff}  />
            {/if}

        </div>
</div>




<style>

.disabledVideo {
    opacity: 0.2
}
.wrapper {
    position: relative;
    width:53px;
    height:40px;
    border-radius:5px;
    background:black;
    overflow:hidden;
    margin-right:10px;
    margin-top:-20px;
    cursor:pointer;

}

.wrapper div {
    position:absolute;
    top:7px;
    left:14px;
    width:100%;
    
    height:100%;
    pointer-events: none;
}

video {
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    border-radius: 5px;
    pointer-events: none;
}

</style>