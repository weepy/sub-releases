<script>
import { nativeBridge } from '../stores/NativeStore.js';
import { onMount} from 'svelte'


onMount(() => {

    const a = (inputName)
    const b = (outputName)
    nativeBridge.send("AUDIO_SESSION_INIT", {inputName: a, outputName: b})


    return () => {
        nativeBridge.send("STOP_CAPTURE")
    }
})

export let inputName
export let outputName
// export let devices

// $: inputDevice = devices.find(d => d.name == inputDeviceName)
// $: outputDevice = devices.find(d => d.name == outputDeviceName)
// $: inputDeviceId = inputDevice ? inputDevice.id : null
// $: outputDeviceId = outputDevice ? outputDevice.id : null


$: {
    if(inputName != "" && outputName != "") {    
        // nativeBridge.send("UPDATE_AUDIO_DEVICES", {inputName, outputName})
    }
    else {
        nativeBridge.send("STOP_CAPTURE")
    }

}

</script>
