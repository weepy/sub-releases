<script>
    import { Button, Dialog, Card,CardText,CardActions,CardTitle } from 'svelte-materialify';
      
    let active = false;
    let msg
    
    window.alert = (_msg) => {
        msg = _msg
        active = true;
    }    

    function close() {
        active=false
    }
</script>
        
    
<!-- <div class="text-center">
<Button on:click={open}>Open Dialog</Button>
</div> -->

<!-- <div style="width:400px"> -->
<Dialog bind:active style="width:400px; backgrond: #333" class="alert pa-5">
    <!-- <Card style="border:1px solid rgba(255,255,255,0.1);"> -->
        <!-- <CardTitle>Alert</CardTitle> -->

        <!-- <CardText> -->
            <p>{@html msg}</p>
          <!-- </CardText> -->
          <!-- <CardActions> -->
            <Button on:click={close} class="primary-color">OK</Button>
            
        <!-- </CardActions> -->

    <!-- </Card> -->

</Dialog>
<!-- </div> -->

