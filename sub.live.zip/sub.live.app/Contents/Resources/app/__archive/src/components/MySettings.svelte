<script>
    import { mdiRefresh, mdiInformationOutline, mdiVolumeHigh, mdiVolumeOff, mdiArrowLeftRight, mdiBuffer } from '@mdi/js'
    import Range from './ui/Range.svelte'
    
    import tooltip from './ui/tooltip.js'

    import { Icon, Dialog, Switch } from 'svelte-materialify'
    // import Info from './Info.svelte'

    import AudioDeviceSelect from '../components/AudioDeviceSelect.svelte'  
    import { myStreamId } from '../stores/Shared.js'
    import { channelSettings, updateChannelSettings } from '../stores/ChannelSettings.js'
    // import { refreshDevices } from '../stores/NativeStore'
    
    let settings = channelSettings[$myStreamId] || {}

    export let active = false

    let {
        gain = 1.0,
        pan = 0.5,
        muted = true,
        buffer = 0
    } = settings

    // $: monitoring = !muted


    $: updateChannelSettings($myStreamId, { pan } ) 
    $: updateChannelSettings($myStreamId, { buffer } ) 
    $: updateChannelSettings($myStreamId, { gain } )
    $: updateChannelSettings($myStreamId, { muted } )
    
    
    function mutedChanged(e) {
        console.log(e.target.checked)

        muted = !e.target.checked
        
    }

  
</script>

<Dialog bind:active={active}>
        
    <div class="pa-5">
        

    
    <!-- <div class="refresh" on:click={()=>refreshDevices()}>
        <Icon size={16} path={mdiRefresh} />
    </div> -->

    

    <AudioDeviceSelect />

    <hr/>
    
     
    <h7 class="mb-2 d-flex" >
        <span class="pr-3">Input Monitoring</span>
        <Switch checked={!muted} on:change={mutedChanged}>{muted ? "off":"on"}</Switch>

        <!-- <div style="margin-left:auto">
            <Info ></Info>
        </div> -->
    </h7>
        
    <div class:muted>

        
        <div class="input-wrapper" >
            <!-- <div class="icon icon-gain"  use:tooltip={{text: "Monitor Level"}}>
                <Icon path={muted ? mdiVolumeOff : mdiVolumeHigh} size={20} />
            </div> -->
            <label>Level</label>
            <Range style="margin-top:15px"  hue={180} min={0} max={2} step={0.01} bind:value={gain} />
            
            
        </div>


        <div class="input-wrapper">
            <!-- <div class="icon" use:tooltip={{text:"Monitor Pan"}}>
                <Icon path={mdiArrowLeftRight} size={20} />
            </div> -->
            <label>Pan</label>
            <Range style="margin-top:15px"  hue={99} min={0} max={1} step={0.01} bind:value={pan} />
        </div>


        <div class="input-wrapper">
            <!-- <div class="icon" use:tooltip={{text:"Buffer Size"}}>
                <Icon path={mdiBuffer} size={20} />
            </div> -->
            <label>Buffer</label>
            <Range style="margin-top:15px" hue={290} min={0} max={16} step={1} bind:value={buffer} />
            <input type="text" disabled value={buffer}>
        </div>

    </div>

</div>
    
</Dialog>

<style>

    h7 {
        
        padding-top: 20px;
    }
  
  h7 span {
      margin-right: 20px;
  }

    .input-wrapper  {
        display:flex;
        margin-bottom: 18px
    }
    .input-wrapper .icon {

        margin: 0px 10px 0px 0px;
        padding: 5px 10px;
    }


    hr {
    border: 0;
    border-top: 1px solid #444;
    width: 260px;
    margin-left: 25px;
}

    label {
        width: 100px;
    font-size: 12px;
    line-height: 36px;
    /* font-weight: bold; */
    font-family: Helvetica;
}


    input[type=text] {
        border: 1px solid #777;
    width: 22px;
    border-radius: 5px;
    padding: 0;
    text-align: center;
    color: #cacaca;
    font-family: arial;
    margin-left: 10px;
    height: 23px;
    margin-top: 8px;
    font-size: 10px;
    
    }

    .muted {
        filter: saturate(0);
        
    }

    .muted label { 
        opacity: 0.2;
        
    }

    /* .icon-gain {
        cursor: pointer !important;
        border-radius: 6px;
        border: 1px solid #292929;
    }
    .icon-gain:hover {
       
        border-color: #888;
    } */

    :global(.muted input) {
        opacity: 0.25
    }

    
    /* .disabled .icon-gain {
        opacity: 1.0 !important;
         */
    /* } */

</style>