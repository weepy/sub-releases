<script>
export let tof = 0
export let mean = 0
export let min = 0
export let max = 0
export let dev = null
export let missed = null

</script>

<div class="wrapper">
    {#if missed == null || missed >= 400 }
        <div>Waiting for audio</div>
    {:else}
        <div><span style="margin-left:0">lag=</span>{tof == null ? "": tof+"ms"}</div>
        <div><span>buffer=</span>{mean}±{dev}[{min}-{max}]</div>
        <div><span>lost=</span>{missed == null ? "" : Math.floor(missed/4)+"%"}</div>
    {/if}
</div>

<style>


div {
    display: inline-block;
    font-size: 10px;
    font-family: arial;
    
}

.wrapper {
    width: 100%;
    text-align: center;
}

span {
    font-weight: normal;
    margin-left:5px;
    
}
</style>