<script>
    import { Dialog} from 'svelte-materialify'
    import { tcpState } from '../stores/WebStore.js'

    import { currentUser } from '../stores/Shared.js'
    import { udpAddress } from '../stores/NativeStore.js'

    export let showDebug = false

    const configHash = localStorage.configHash || (document.location.hash.slice(1))
</script>


<Dialog bind:active={showDebug}>
    <div style="background:#343c44; text-align: center" class="pa-5"  >
        <h7>Debug</h7>
        <p> Config: { configHash.split(",").join("\n") } </p>
        <p> User: {$currentUser ? JSON.stringify($currentUser) : "None"}</p>
        <p> TCP: {$tcpState} </p>
        <p> UDP: {$udpAddress} </p>


    </div>

</Dialog>